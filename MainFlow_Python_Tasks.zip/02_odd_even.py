n=int(input("Enter number: "))
if n%2==0:
    print("Even")
else:
    print("Odd")
